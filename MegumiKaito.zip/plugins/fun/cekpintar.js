import { rbRun, rbRegister } from './_engine.js'

// ───────── logika fitur (sebelumnya di lib/) ─────────
const feature = async ({ rbG, rbLib }) => {
  function getTarget(m, text) {
    if (m.mentionedJid && m.mentionedJid.length > 0) {
      const jid = m.mentionedJid[0]
      const num = jid.replace(/[^0-9]/g, '')
      return { name: `@${num}`, jid, mentions: [jid] }
    }
    if (m.quoted && m.quoted.sender) {
      const jid = m.quoted.sender
      const num = jid.replace(/[^0-9]/g, '')
      return { name: `@${num}`, jid, mentions: [jid] }
    }
    if (text && text.trim()) {
      return { name: text.trim(), jid: null, mentions: [] }
    }
    const selfNum = (m.sender || '').replace(/[^0-9]/g, '')
    return { name: `@${selfNum}`, jid: m.sender, mentions: [m.sender] }
  }

  const handler = async (m, { text }) => {
    const target = getTarget(m, text)
    const score = Math.floor(Math.random() * 70) + 80
    await m.reply(`╭─── ୨୧ CEK PINTAR ୨୧ ───╮\n│ ૮₍˶ᵔ ᵕ ᵔ˶₎ა estimasi IQ!\n╰────────────────────────╯\n\n୨ৎ Target: ${target.name}\n୨ৎ IQ Score: *${score}* 🧠`, null, { mentions: target.mentions })
  }
  handler.help = ['cekpintar [@tag/nama]']
  handler.tags = ['fun']
  handler.command = ['cekpintar']
  return handler
}

rbRegister("fun/cekpintar", feature)

let handler = (m, ctx) => rbRun("fun/cekpintar", m, ctx)

handler.command = ['cekpintar']
handler.help = ["cekpintar [@tag/nama]"]
handler.tags = ['fun']

export default handler
